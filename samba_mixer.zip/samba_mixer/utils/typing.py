from typing import Union


Number = Union[int, float]
